﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CorrecaoBanco
{
    class ContaCorrente : Conta
    {
        public decimal TaxaManutencao { get; set; }

        public ContaCorrente(Cliente cliente) : base(cliente)
        {
            TipoConta = "Corrente";
            TaxaManutencao = 1.50m;
        }

        public override void Transferir()
        {
            Console.WriteLine("Insira o valor desejado: ");
            decimal valor = decimal.Parse(Console.ReadLine());
            if (Saldo < valor + TaxaManutencao)
            {
                Console.WriteLine($"Você não tem saldo suficiente para essa transferência!\nSaldo: R${Saldo}");
            }
            else
            {
                Saldo -= valor + TaxaManutencao;
                base.ClassificarCliente();
                Console.WriteLine($"Você depositou dinheiro na conta!\nSaldo após o depósito: R${Saldo}");
            }
        }
    }

}
