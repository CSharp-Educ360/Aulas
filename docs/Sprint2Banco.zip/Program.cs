﻿using System;

namespace CorrecaoBanco
{
    internal class Program
    {
        static void Main(string[] args)
        {

            var cliente = new Cliente();
            var cc = new ContaCorrente(cliente);
            
            ChamarMenu(cc);
        }

        public static int GuardarOpcao(Conta conta)
        {
            bool isValido;
            string opcao;
            do
            {
                Console.WriteLine("Menu - escolha a opção desejada de acordo com o número: ");
                Console.WriteLine(@$"
                    1- Cadastrar Cliente
                    2- Depositar Dinheiro
                    3- Transferir Dinheiro
                    4- Consultar Saldo/Dados da Conta {conta.TipoConta}
                    5- Sair");
                opcao = Console.ReadLine();
                isValido = int.Parse(opcao) > 0 && int.Parse(opcao) <= 5;
                if (!isValido)
                {
                    Console.WriteLine("Você digitou uma opção inválida! Tente novamente!");
                }
            } while (!isValido);

            return int.Parse(opcao);
        }


        public static void ChamarMenu(Conta conta)
        {

            string respostaCpf = "";
            string respostaNome = "";
            int opcao = GuardarOpcao(conta);
            do
            {
                switch (opcao)
                {
                    case 1:
                        conta.Cliente.CadastrarDados(respostaCpf, respostaNome);
                        opcao = GuardarOpcao(conta);
                        break;
                    case 2:
                        conta.Depositar();
                        opcao = GuardarOpcao(conta);
                        break;
                    case 3:
                        conta.Transferir();
                        opcao = GuardarOpcao(conta);
                        break;
                    case 4:
                        conta.ConsultarSaldo();
                        opcao = GuardarOpcao(conta);
                        break;
                }
            } while (opcao != 5);
            Console.WriteLine("Programa encerrado!");
        }
    }
}
