﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CorrecaoBanco
{
    class ContaPoupanca
    {
    //Pratique! Inclua herança e polimorfismo nessa classe a partir da classe base Conta
    }
}
