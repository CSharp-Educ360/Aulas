﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CorrecaoBanco
{
    abstract class Conta
    {
        public string Numero { get; set; }
        public decimal Saldo { get; protected set; }
        public Cliente Cliente { get; set; }
        public string TipoConta { get; set; }


        public Conta(Cliente cliente)
        {
            Cliente = cliente;
            Saldo = 0;
        }

        protected TipoCliente ClassificarCliente()
        {
            if(Saldo >= 15000)
            {
                return Cliente.Tipo = TipoCliente.Premium;
            }

            else if (Saldo >= 5000 && Saldo <= 14999)
            {
                return Cliente.Tipo = TipoCliente.Super;
            }
            else
            {
                return Cliente.Tipo = TipoCliente.Comum;
            }
        }

        public abstract void Transferir();

        public void Depositar()
        {
            Console.WriteLine("Insira o valor desejado: ");
            decimal valor = decimal.Parse(Console.ReadLine());
            Saldo += valor;
            ClassificarCliente();
            Console.WriteLine($"Você depositou dinheiro na conta!\nSaldo após depósito: R${Saldo}");
        }

        public void ConsultarSaldo()
        {
            Console.WriteLine($"Esta conta pertence a : {Cliente.Nome} - CPF: {Cliente.Cpf}");
            Console.WriteLine($"Número da conta: {Numero}");
            Console.WriteLine($"O saldo atual é de R$ {Saldo}");
            Console.WriteLine($"O cliente é do tipo {Cliente.Tipo}");
        }


    }
}

