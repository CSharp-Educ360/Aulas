﻿namespace CorrecaoBanco
{
    public enum TipoCliente
    {
        Comum, Super, Premium
    }
}